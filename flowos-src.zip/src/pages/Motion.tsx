import { useState, useMemo, useEffect } from 'react'
import type { ExecutionSettings } from '../data/types'
import FlowPageHeader from '../components/FlowPageHeader'
import FlowTabs from '../components/FlowTabs'
import ExecutionSettingsCard from '../components/ExecutionSettingsCard'
import { supabase } from '../lib/supabaseClient'
import { useUser } from '../components/AuthGate'

interface Props {
  settings: ExecutionSettings
  onSaveSettings: (updated: ExecutionSettings) => void
}

const TABS = [
  { id: 'overview',  label: 'Overview'  },
  { id: 'deep-work', label: 'Ops'       },
  { id: 'pipeline',  label: 'Pipeline'  },
  { id: 'feedback',  label: 'Feedback'  },
]

const STAGE_REVENUE      = 3000
const STAGE_SVC_EMAILS   = 500
const STAGE_SVC_CALLS    = 700
const STAGE_SVC_DEALS    = 5

// ─── Motion Stage System ──────────────────────────────────────────────────────
type MotionMetricId     = 'emails_sent' | 'calls_done' | 'meetings_booked' | 'meetings_held' | 'deals_closed' | 'revenue'
type MotionMetricStatus = 'required' | 'focus' | 'maintained' | 'tracked'

type MotionStageDef = {
  id:                number
  name:              string
  revenueThreshold:  number   // stage 1 = cumulative total; stages 2–5 = per-month target
  consistencyMonths: number   // 0 = cumulative check only; 2+ = consecutive months required
  metrics:           Record<MotionMetricId, MotionMetricStatus>
}

// Stage progression = revenue only (strict rule)
const MOTION_STAGES: MotionStageDef[] = [
  {
    id: 1, name: 'Self-Control', revenueThreshold: 3_000, consistencyMonths: 1,
    metrics: {
      emails_sent:     'required',   // outreach = foundation
      calls_done:      'required',
      meetings_booked: 'focus',
      meetings_held:   'tracked',
      deals_closed:    'required',
      revenue:         'tracked',
    },
  },
  {
    id: 2, name: 'Stability', revenueThreshold: 5_000, consistencyMonths: 2,
    metrics: {
      emails_sent:     'maintained',
      calls_done:      'maintained',
      meetings_booked: 'focus',
      meetings_held:   'focus',
      deals_closed:    'required',
      revenue:         'required',
    },
  },
  {
    id: 3, name: 'Growth', revenueThreshold: 7_000, consistencyMonths: 3,
    metrics: {
      emails_sent:     'maintained',
      calls_done:      'maintained',
      meetings_booked: 'tracked',
      meetings_held:   'focus',
      deals_closed:    'focus',
      revenue:         'required',
    },
  },
  {
    id: 4, name: 'Independence', revenueThreshold: 10_000, consistencyMonths: 4,
    metrics: {
      emails_sent:     'maintained',
      calls_done:      'maintained',
      meetings_booked: 'maintained',
      meetings_held:   'maintained',
      deals_closed:    'focus',
      revenue:         'required',
    },
  },
  {
    id: 5, name: 'Expansion', revenueThreshold: 15_000, consistencyMonths: 6,
    metrics: {
      emails_sent:     'maintained',
      calls_done:      'maintained',
      meetings_booked: 'maintained',
      meetings_held:   'maintained',
      deals_closed:    'focus',
      revenue:         'required',
    },
  },
]

const MOTION_METRIC_LABELS: Record<MotionMetricId, string> = {
  emails_sent:     'Emails sent',
  calls_done:      'Calls done',
  meetings_booked: 'Meetings booked',
  meetings_held:   'Meetings held',
  deals_closed:    'Deals closed',
  revenue:         'Revenue',
}

const MOTION_STATUS_CFG: Record<MotionMetricStatus, { label: string; dot: string; text: string; bg: string; border: string }> = {
  required:   { label: 'Required',   dot: 'bg-red-400',      text: 'text-red-400/80',      bg: 'bg-red-500/6',      border: 'border-red-500/15'      },
  focus:      { label: 'Focus',      dot: 'bg-emerald-400',  text: 'text-emerald-400/80',  bg: 'bg-emerald-500/6',  border: 'border-emerald-500/15'  },
  maintained: { label: 'Maintained', dot: 'bg-blue-400',     text: 'text-blue-400/80',     bg: 'bg-blue-500/6',     border: 'border-blue-500/15'     },
  tracked:    { label: 'Tracked',    dot: 'bg-white/20',     text: 'text-white/35',        bg: 'bg-white/3',        border: 'border-white/6'         },
}

// ─── Types ────────────────────────────────────────────────────────────────────
type ServiceRecord = {
  date: string
  emails: number; calls: number
  meetingsBooked: number; meetingsHeld: number; deals: number
  revenue: number
}
type AmazonRecord = {
  date: string
  productsAnalyzed: number; productsListed: number
  orders: number; revenue: number
}
type WorkSession = {
  id: string; date: string
  type: 'service' | 'amazon'
  category: 'building' | 'outreach' | 'calls' | 'follow-ups' | 'meetings' | 'fulfillment' | 'product-analysis' | 'listing' | 'sourcing' | 'feedback'
  isDeepWork?: boolean   // optional — existing records without this field treated as false
  minutes: number; note: string
}

// ─── Storage ──────────────────────────────────────────────────────────────────
const LS_SVC      = 'motion_service'
const LS_AMZ      = 'motion_amazon'
const LS_SESSIONS = 'motion_sessions'

function lsGet<T>(key: string, fb: T): T {
  try { const v = localStorage.getItem(key); return v ? (JSON.parse(v) as T) : fb } catch { return fb }
}
function lsSet(key: string, val: unknown): void {
  try { localStorage.setItem(key, JSON.stringify(val)) } catch {}
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function motionToday(): string { return new Date().toISOString().slice(0, 10) }
// Week boundary: Sunday 00:00 → Saturday 23:59
function motionWeekSunday(): string {
  const d = new Date()
  d.setDate(d.getDate() - d.getDay())   // getDay() === 0 on Sun → no change; otherwise steps back
  return d.toISOString().slice(0, 10)
}
// Sunday of N complete weeks ago (1 = last week, 2 = two weeks ago, etc.)
function sundayOfWeeksAgo(n: number): string {
  const d = new Date()
  d.setDate(d.getDate() - d.getDay() - n * 7)
  return d.toISOString().slice(0, 10)
}
function isWeekday(iso: string): boolean {
  const d = new Date(iso + 'T12:00:00').getDay(); return d >= 1 && d <= 5
}
function fmtMin(m: number): string {
  if (m === 0) return '0m'
  if (m < 60) return `${m}m`
  const h = Math.floor(m / 60), r = m % 60
  return r === 0 ? `${h}h` : `${h}h ${r}m`
}
const blankSvc = (d: string): ServiceRecord =>
  ({ date: d, emails: 0, calls: 0, meetingsBooked: 0, meetingsHeld: 0, deals: 0, revenue: 0 })
const blankAmz = (d: string): AmazonRecord =>
  ({ date: d, productsAnalyzed: 0, productsListed: 0, orders: 0, revenue: 0 })

const CAT_LABEL: Record<WorkSession['category'], string> = {
  'building':        'Building',
  'outreach':        'Outreach',
  'calls':           'Calls',
  'follow-ups':      'Follow-ups',
  'meetings':        'Meetings',
  'fulfillment':     'Fulfillment',
  'product-analysis':'Product Analysis',
  'listing':         'Listing',
  'sourcing':        'Sourcing',
  'feedback':        'Feedback',
}
const SVC_CATS = ['building', 'outreach', 'calls', 'follow-ups', 'meetings', 'fulfillment', 'feedback'] as const
const AMZ_CATS = ['product-analysis', 'listing', 'sourcing', 'feedback'] as const

// ─── Auto priority system ────────────────────────────────────────────────────
type PriorityKey = 'calls' | 'emails' | 'products' | 'deep_work'
type AutoPriority = {
  key:        PriorityKey
  label:      string
  nextAction: string
  done:       number
  target:     number
  pct:        number
  complete:   boolean
}
const AUTO_NEXT_ACTIONS: Record<PriorityKey, string> = {
  calls:     'Make 3 calls (45 min)',
  emails:    'Send 10 emails (30 min)',
  products:  'Analyze 10 products (45 min)',
  deep_work: 'Deep work session (60 min)',
}

// ─── Monthly revenue helpers ──────────────────────────────────────────────────
function buildMonthlyRevMap(svcLog: ServiceRecord[], amzLog: AmazonRecord[]): Map<string, number> {
  const m = new Map<string, number>()
  for (const r of svcLog) {
    const k = r.date.slice(0, 7); m.set(k, (m.get(k) ?? 0) + r.revenue)
  }
  for (const r of amzLog) {
    const k = r.date.slice(0, 7); m.set(k, (m.get(k) ?? 0) + r.revenue)
  }
  return m
}
// Count consecutive calendar months (starting from current month, going back) where revenue ≥ threshold
function consecutiveMonthsAbove(revMap: Map<string, number>, threshold: number): number {
  let count = 0
  const d = new Date()
  for (let i = 0; i < 24; i++) {
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
    if ((revMap.get(key) ?? 0) < threshold) break
    count++
    d.setMonth(d.getMonth() - 1)
  }
  return count
}

// ─── Component ────────────────────────────────────────────────────────────────
export default function Motion({ settings, onSaveSettings }: Props) {
  const today        = motionToday()
  const isWkdayToday = isWeekday(today)
  const user         = useUser()

  const [activeTab,   setActiveTab]   = useState('overview')
  const [pipeView,    setPipeView]    = useState<'service' | 'amazon'>('service')
  const [serviceLog,  setServiceLog]  = useState<ServiceRecord[]>(() => lsGet(LS_SVC, []))
  const [amazonLog,   setAmazonLog]   = useState<AmazonRecord[]>(() => lsGet(LS_AMZ, []))
  const [sessions,    setSessions]    = useState<WorkSession[]>(() => lsGet(LS_SESSIONS, []))
  const [sessionForm, setSessionForm] = useState({
    type:        'service'   as WorkSession['type'],
    category:    'outreach'  as WorkSession['category'],
    isDeepWork:  false,
    minutes:     30, note: '',
  })
  const [svcRevInput, setSvcRevInput] = useState('')
  const [amzRevInput, setAmzRevInput] = useState('')

  // ── Load all Motion data from Supabase on mount ───────────────────────────
  useEffect(() => {
    if (!user) return

    // service_records — full history for cumulative totals + weekly calcs
    supabase
      .from('service_records')
      .select('record_date,emails,calls,meetings_booked,meetings_held,deals,revenue')
      .eq('user_id', user.id)
      .then(({ data, error }) => {
        if (error) { console.error('[motion] fetch service_records:', error); return }
        if (!data?.length) return
        const mapped: ServiceRecord[] = data.map(r => ({
          date:           r.record_date,
          emails:         r.emails          ?? 0,
          calls:          r.calls           ?? 0,
          meetingsBooked: r.meetings_booked ?? 0,
          meetingsHeld:   r.meetings_held   ?? 0,
          deals:          r.deals           ?? 0,
          revenue:        r.revenue         ?? 0,
        }))
        setServiceLog(mapped)
        lsSet(LS_SVC, mapped)
      })

    // amazon_records — full history
    supabase
      .from('amazon_records')
      .select('record_date,products_analyzed,products_listed,orders_count,revenue')
      .eq('user_id', user.id)
      .then(({ data, error }) => {
        if (error) { console.error('[motion] fetch amazon_records:', error); return }
        if (!data?.length) return
        const mapped: AmazonRecord[] = data.map(r => ({
          date:             r.record_date,
          productsAnalyzed: r.products_analyzed ?? 0,
          productsListed:   r.products_listed   ?? 0,
          orders:           r.orders_count       ?? 0,
          revenue:          r.revenue            ?? 0,
        }))
        setAmazonLog(mapped)
        lsSet(LS_AMZ, mapped)
      })

    // work_sessions — last 200 for history
    supabase
      .from('work_sessions')
      .select('id,session_date,type,category,is_deep_work,minutes,note')
      .eq('user_id', user.id)
      .order('session_date', { ascending: false })
      .limit(200)
      .then(({ data, error }) => {
        if (error) { console.error('[motion] fetch work_sessions:', error); return }
        if (!data?.length) return
        const mapped: WorkSession[] = data.map(r => ({
          id:         String(r.id),
          date:       r.session_date,
          type:       r.type       as WorkSession['type'],
          category:   r.category   as WorkSession['category'],
          isDeepWork: r.is_deep_work ?? false,
          minutes:    r.minutes,
          note:       r.note ?? '',
        }))
        setSessions(mapped)
        lsSet(LS_SESSIONS, mapped)
      })

    // execution_settings — single row per user; hydrate App settings state
    supabase
      .from('execution_settings')
      .select('emails_per_day,calls_per_day,products_per_day,deep_work_min_per_day')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data, error }) => {
        if (error) { console.error('[motion] fetch execution_settings:', error); return }
        if (!data) return
        onSaveSettings({
          emailsPerDay:      data.emails_per_day       ?? settings.emailsPerDay,
          callsPerDay:       data.calls_per_day         ?? settings.callsPerDay,
          productsPerDay:    data.products_per_day      ?? settings.productsPerDay,
          deepWorkMinPerDay: data.deep_work_min_per_day ?? settings.deepWorkMinPerDay,
          lastUpdated:       today,
        })
      })

  }, [user]) // eslint-disable-line react-hooks/exhaustive-deps

  // ── Today ──────────────────────────────────────────────────────────────────
  const todaySvc      = serviceLog.find(r => r.date === today) ?? null
  const todayAmz      = amazonLog.find(r => r.date === today)  ?? null
  const todaySessions = sessions.filter(s => s.date === today)
  const todayDwMin    = todaySessions.reduce((s, r) => s + r.minutes, 0)

  // ── Stage totals (all-time cumulative) ────────────────────────────────────
  const stageTotals = useMemo(() => {
    const svc = serviceLog.reduce((a, r) => ({
      emails: a.emails + r.emails, calls: a.calls + r.calls,
      deals:  a.deals  + r.deals,  revenue: a.revenue + r.revenue,
    }), { emails: 0, calls: 0, deals: 0, revenue: 0 })
    const amz = amazonLog.reduce((a, r) => ({
      productsAnalyzed: a.productsAnalyzed + r.productsAnalyzed,
      productsListed:   a.productsListed   + r.productsListed,
      orders: a.orders + r.orders, revenue: a.revenue + r.revenue,
    }), { productsAnalyzed: 0, productsListed: 0, orders: 0, revenue: 0 })
    return { svc, amz, totalRevenue: svc.revenue + amz.revenue }
  }, [serviceLog, amazonLog])

  // ── Current-month revenue (stage validation window) ───────────────────────
  // Each calendar month is independent — no carry-over between months.
  const currentMonthRev = useMemo(() => {
    const prefix = new Date().toISOString().slice(0, 7)   // "YYYY-MM"
    const svc = serviceLog.filter(r => r.date.startsWith(prefix)).reduce((s, r) => s + r.revenue, 0)
    const amz = amazonLog.filter(r => r.date.startsWith(prefix)).reduce((s, r) => s + r.revenue, 0)
    return { svc, amz, total: svc + amz }
  }, [serviceLog, amazonLog])

  const revPct = Math.min(100, Math.round((currentMonthRev.total / STAGE_REVENUE) * 100))

  // ── Weekly days (Sun–Sat) ──────────────────────────────────────────────────
  const weekDays = useMemo(() => {
    const sun = motionWeekSunday()
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(sun + 'T12:00:00')
      d.setDate(d.getDate() + i)
      const iso = d.toISOString().slice(0, 10)
      return { iso, label: d.toLocaleDateString('en-GB', { weekday: 'short' }), num: d.getDate(), isToday: iso === today, isFuture: iso > today }
    })
  }, [today])

  // ── Adaptive effective targets ─────────────────────────────────────────────
  const effectiveTargets = useMemo(() => {
    const wkRecs  = serviceLog.filter(r => isWeekday(r.date)).sort((a, b) => b.date.localeCompare(a.date))
    const wkeRecs = amazonLog.filter(r => !isWeekday(r.date)).sort((a, b) => b.date.localeCompare(a.date))
    const last5   = wkRecs.slice(0, 5)
    const last3   = wkRecs.slice(0, 3)
    const lastWke = wkeRecs.slice(0, 4)

    let emails   = settings.emailsPerDay
    let calls    = settings.callsPerDay
    let products = settings.productsPerDay

    // Service: 5-day avg < 60% → reduce 20%
    if (last5.length >= 3) {
      if (last5.reduce((s, r) => s + r.emails / settings.emailsPerDay, 0) / last5.length < 0.6)
        emails = Math.max(1, Math.round(settings.emailsPerDay * 0.8))
      if (last5.reduce((s, r) => s + r.calls / settings.callsPerDay, 0) / last5.length < 0.6)
        calls = Math.max(1, Math.round(settings.callsPerDay * 0.8))
    }
    // Service: 3 consecutive days > 110% → increase 20%, clamp
    if (last3.length === 3) {
      if (last3.every(r => r.emails / settings.emailsPerDay > 1.1)) emails = Math.min(50, Math.round(settings.emailsPerDay * 1.2))
      if (last3.every(r => r.calls  / settings.callsPerDay  > 1.1)) calls  = Math.min(15, Math.round(settings.callsPerDay  * 1.2))
    }

    // Amazon analyzed: weekend completion < 50% → reduce 25%; > 120% → increase 25%
    if (lastWke.length >= 2) {
      const pAvg = lastWke.reduce((s, r) => s + r.productsAnalyzed / settings.productsPerDay, 0) / lastWke.length
      if (pAvg < 0.5) products = Math.max(1, Math.round(settings.productsPerDay * 0.75))
      if (pAvg > 1.2) products = Math.round(settings.productsPerDay * 1.25)
    }

    // Amazon listed: adapts independently from its own completion history
    const baseListed = Math.max(1, Math.round(settings.productsPerDay * 0.5))
    let listed = baseListed
    if (lastWke.length >= 2) {
      const lAvg = lastWke.reduce((s, r) => s + r.productsListed / baseListed, 0) / lastWke.length
      if (lAvg < 0.5) listed = Math.max(1, Math.round(baseListed * 0.75))
      if (lAvg > 1.2) listed = Math.round(baseListed * 1.25)
    }

    const listedAdapted  = listed   !== baseListed
    const anyAdapted     = emails !== settings.emailsPerDay || calls !== settings.callsPerDay || products !== settings.productsPerDay || listedAdapted

    return {
      emailsPerDay:         emails,
      callsPerDay:          calls,
      productsPerDay:       products,
      productsListedPerDay: listed,
      deepWorkMinPerDay:    settings.deepWorkMinPerDay,
      emailsAdapted:        emails   !== settings.emailsPerDay,
      callsAdapted:         calls    !== settings.callsPerDay,
      productsAdapted:      products !== settings.productsPerDay,
      listedAdapted,
      anyAdapted,
    }
  }, [serviceLog, amazonLog, settings])

  // ── Weekly data ───────────────────────────────────────────────────────────
  const weeklyData = useMemo(() => {
    const wkSet   = new Set(weekDays.map(d => d.iso))
    const past    = weekDays.filter(d => !d.isFuture && !d.isToday)
    const pastWkd = past.filter(d => isWeekday(d.iso))
    const pastWke = past.filter(d => !isWeekday(d.iso))

    const svcRecs  = serviceLog.filter(r => wkSet.has(r.date))
    const amzRecs  = amazonLog.filter(r => wkSet.has(r.date))
    const sessRecs = sessions.filter(s => wkSet.has(s.date))

    const svc = svcRecs.reduce((a, r) => ({
      emails: a.emails + r.emails, calls: a.calls + r.calls,
      meetingsBooked: a.meetingsBooked + r.meetingsBooked,
      meetingsHeld:   a.meetingsHeld   + r.meetingsHeld,
      deals: a.deals + r.deals, revenue: a.revenue + r.revenue,
    }), { emails: 0, calls: 0, meetingsBooked: 0, meetingsHeld: 0, deals: 0, revenue: 0 })

    const amz = amzRecs.reduce((a, r) => ({
      productsAnalyzed: a.productsAnalyzed + r.productsAnalyzed,
      productsListed:   a.productsListed   + r.productsListed,
      orders: a.orders + r.orders, revenue: a.revenue + r.revenue,
    }), { productsAnalyzed: 0, productsListed: 0, orders: 0, revenue: 0 })

    const dwMin = sessRecs.reduce((s, r) => s + r.minutes, 0)

    // Conversions
    const contacts       = svc.emails + svc.calls
    const emailCallToMtg = contacts          > 0 ? Math.round((svc.meetingsBooked / contacts)          * 100) : null
    const mtgBookedHeld  = svc.meetingsBooked > 0 ? Math.round((svc.meetingsHeld   / svc.meetingsBooked) * 100) : null
    const mtgHeldDeal    = svc.meetingsHeld   > 0 ? Math.round((svc.deals          / svc.meetingsHeld)   * 100) : null
    const analyzedListed = amz.productsAnalyzed > 0 ? Math.round((amz.productsListed / amz.productsAnalyzed) * 100) : null
    const listedOrder    = amz.productsListed   > 0 ? Math.round((amz.orders          / amz.productsListed)   * 100) : null

    // Per-metric completion rates — each metric vs its own adaptive target
    function pct(actual: number, target: number, n: number): number | null {
      if (n === 0 || target === 0) return null
      return Math.min(100, Math.round((actual / (n * target)) * 100))
    }
    // Service metrics (weekdays)
    const emailsPct   = pct(svc.emails,              effectiveTargets.emailsPerDay,         pastWkd.length)
    const callsPct    = pct(svc.calls,               effectiveTargets.callsPerDay,           pastWkd.length)
    // deals: target 1 deal per 5 weekdays (0.2/day) — own independent rate
    const dealsPct    = pastWkd.length > 0 ? Math.min(100, Math.round(svc.deals / (pastWkd.length * 0.2) * 100)) : null
    // Amazon metrics (weekends)
    const productsPct = pct(amz.productsAnalyzed,    effectiveTargets.productsPerDay,        pastWke.length)
    const listedPct   = pct(amz.productsListed,      effectiveTargets.productsListedPerDay,  pastWke.length)
    // orders: target 1 order per 2 weekend days (0.5/day) — own independent rate
    const ordersPct   = pastWke.length > 0 ? Math.min(100, Math.round(amz.orders / (pastWke.length * 0.5) * 100)) : null
    // Shared
    const dwPct       = pct(dwMin,                   effectiveTargets.deepWorkMinPerDay,     past.length)

    // Weakest = single metric with lowest completion rate (across all 7)
    const scored = [
      { label: 'Emails',    pct: emailsPct   },
      { label: 'Calls',     pct: callsPct    },
      { label: 'Deals',     pct: dealsPct    },
      { label: 'Analyzed',  pct: productsPct },
      { label: 'Listed',    pct: listedPct   },
      { label: 'Orders',    pct: ordersPct   },
      { label: 'Deep Work', pct: dwPct       },
    ].filter((c): c is { label: string; pct: number } => c.pct !== null)
    const weakest = scored.length === 0 ? null : scored.reduce((a, b) => a.pct <= b.pct ? a : b)

    const missed: string[] = []
    for (const day of past) {
      const s  = serviceLog.find(r => r.date === day.iso)
      const az = amazonLog.find(r => r.date === day.iso)
      const dw = sessions.filter(r => r.date === day.iso).reduce((sum, r) => sum + r.minutes, 0)
      if (isWeekday(day.iso)) {
        if (!s || s.emails < effectiveTargets.emailsPerDay)  missed.push(`Emails — ${day.label} ${day.num}`)
        if (!s || s.calls  < effectiveTargets.callsPerDay)   missed.push(`Calls — ${day.label} ${day.num}`)
      } else {
        if (!az || az.productsAnalyzed < effectiveTargets.productsPerDay) missed.push(`Products — ${day.label} ${day.num}`)
      }
      if (dw < effectiveTargets.deepWorkMinPerDay) missed.push(`Deep Work — ${day.label} ${day.num}`)
    }

    return { svc, amz, dwMin, emailCallToMtg, mtgBookedHeld, mtgHeldDeal, analyzedListed, listedOrder, emailsPct, callsPct, dealsPct, productsPct, listedPct, ordersPct, dwPct, weakest, missed, pastWkdCount: pastWkd.length, pastWkeCount: pastWke.length }
  }, [serviceLog, amazonLog, sessions, weekDays, effectiveTargets])

  // ── Weekly history (last 4 complete Sun–Sat weeks) ────────────────────────
  const weeklyHistory = useMemo(() => {
    return Array.from({ length: 4 }, (_, i) => {
      const sunIso = sundayOfWeeksAgo(i + 1)
      const days   = Array.from({ length: 7 }, (_, j) => {
        const d = new Date(sunIso + 'T12:00:00')
        d.setDate(d.getDate() + j)
        return d.toISOString().slice(0, 10)
      })
      const satIso = days[6]
      const daySet = new Set(days)
      const svc = serviceLog.filter(r => daySet.has(r.date)).reduce(
        (a, r) => ({ emails: a.emails + r.emails, calls: a.calls + r.calls, deals: a.deals + r.deals, revenue: a.revenue + r.revenue }),
        { emails: 0, calls: 0, deals: 0, revenue: 0 },
      )
      const amz = amazonLog.filter(r => daySet.has(r.date)).reduce(
        (a, r) => ({ analyzed: a.analyzed + r.productsAnalyzed, listed: a.listed + r.productsListed, orders: a.orders + r.orders, revenue: a.revenue + r.revenue }),
        { analyzed: 0, listed: 0, orders: 0, revenue: 0 },
      )
      const hasData  = svc.emails > 0 || svc.calls > 0 || svc.deals > 0 || amz.analyzed > 0
      const totalRev = svc.revenue + amz.revenue
      // Stage 1 requirements met this week?
      const s1Emails = svc.emails >= Math.round(STAGE_SVC_EMAILS / 52)   // ~10/wk
      const s1Calls  = svc.calls  >= Math.round(STAGE_SVC_CALLS  / 52)   // ~14/wk
      const s1Deals  = svc.deals  >= 0                                    // any deal counts
      return { weekStart: sunIso, weekEnd: satIso, svc, amz, totalRev, hasData, s1Emails, s1Calls, s1Deals }
    })
  }, [serviceLog, amazonLog])

  // ── Motion stage system ───────────────────────────────────────────────────
  const monthlyRevMap = useMemo(
    () => buildMonthlyRevMap(serviceLog, amazonLog),
    [serviceLog, amazonLog],
  )

  const currentMotionStage = useMemo((): MotionStageDef => {
    // Every stage uses consecutive-month validation — no cumulative carry-over.
    // Walk from highest stage down — return the stage AFTER the first completed one.
    for (let i = MOTION_STAGES.length - 1; i >= 0; i--) {
      const stage = MOTION_STAGES[i]
      const done  = consecutiveMonthsAbove(monthlyRevMap, stage.revenueThreshold) >= stage.consistencyMonths
      if (done) return MOTION_STAGES[Math.min(i + 1, MOTION_STAGES.length - 1)]
    }
    return MOTION_STAGES[0]
  }, [monthlyRevMap])

  const nextMotionStage = useMemo((): MotionStageDef | null => {
    const idx = MOTION_STAGES.findIndex(s => s.id === currentMotionStage.id)
    return idx < MOTION_STAGES.length - 1 ? MOTION_STAGES[idx + 1] : null
  }, [currentMotionStage])

  const motionStageProgress = useMemo(() => {
    const stage       = currentMotionStage
    const consecutive = consecutiveMonthsAbove(monthlyRevMap, stage.revenueThreshold)
    return {
      pct:           Math.min(100, Math.round((consecutive / stage.consistencyMonths) * 100)),
      progressLabel: `${consecutive} / ${stage.consistencyMonths} month${stage.consistencyMonths > 1 ? 's' : ''} ≥ $${stage.revenueThreshold.toLocaleString()}/mo`,
      contextLabel:  `This month: $${currentMonthRev.total.toLocaleString()}`,
    }
  }, [currentMotionStage, currentMonthRev, monthlyRevMap])

  // ── Revenue history (derived from monthlyRevMap, no new fetch) ──────────────
  const revenueHistory = useMemo(() => {
    return Array.from(monthlyRevMap.entries())
      .map(([key, rev]) => {
        const [y, m] = key.split('-')
        const label  = new Date(parseInt(y), parseInt(m) - 1, 1)
          .toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
        const isCurrent = key === new Date().toISOString().slice(0, 7)
        return { key, label, rev, isCurrent }
      })
      .sort((a, b) => b.key.localeCompare(a.key))
      .slice(0, 6)
  }, [monthlyRevMap])

  const motionMetricStatuses = useMemo(
    (): Record<MotionMetricId, MotionMetricStatus> => ({ ...currentMotionStage.metrics }),
    [currentMotionStage],
  )

  // ── Persist computed stage to Supabase whenever it changes ───────────────
  useEffect(() => {
    if (!user) return
    supabase
      .from('motion_stage_state')
      .upsert({
        user_id:            user.id,
        current_stage:      currentMotionStage.id,
        stage_name:         currentMotionStage.name,
        revenue_threshold:  currentMotionStage.revenueThreshold,
        consistency_months: currentMotionStage.consistencyMonths,
        status:             'active',
      }, { onConflict: 'user_id' })
      .then(({ error }) => { if (error) console.error('[motion] upsert motion_stage_state:', error) })
  }, [user, currentMotionStage]) // eslint-disable-line react-hooks/exhaustive-deps

  // ── Stage-aware weakest area (required + focus implemented metrics only) ───
  const motionWeakestArea = useMemo(() => {
    const wRev       = weeklyData.svc.revenue + weeklyData.amz.revenue
    const wRevTarget = currentMotionStage.revenueThreshold / 4.3   // approx weekly portion
    const mtgBkdTgt  = Math.max(1, Math.round((weeklyData.svc.emails + weeklyData.svc.calls) * 0.1))
    const mtgHeldTgt = Math.max(1, weeklyData.svc.meetingsBooked)

    const scores: { id: MotionMetricId; label: string; score: number; status: MotionMetricStatus }[] = [
      { id: 'emails_sent',     label: MOTION_METRIC_LABELS['emails_sent'],     score: weeklyData.emailsPct ?? 0,                                                                                           status: motionMetricStatuses['emails_sent']     },
      { id: 'calls_done',      label: MOTION_METRIC_LABELS['calls_done'],      score: weeklyData.callsPct  ?? 0,                                                                                           status: motionMetricStatuses['calls_done']      },
      { id: 'deals_closed',    label: MOTION_METRIC_LABELS['deals_closed'],    score: weeklyData.dealsPct  ?? 0,                                                                                           status: motionMetricStatuses['deals_closed']    },
      { id: 'meetings_booked', label: MOTION_METRIC_LABELS['meetings_booked'], score: Math.min(100, Math.round((weeklyData.svc.meetingsBooked / mtgBkdTgt)  * 100)),                                      status: motionMetricStatuses['meetings_booked'] },
      { id: 'meetings_held',   label: MOTION_METRIC_LABELS['meetings_held'],   score: mtgHeldTgt > 0 ? Math.min(100, Math.round((weeklyData.svc.meetingsHeld / mtgHeldTgt) * 100)) : 0,                   status: motionMetricStatuses['meetings_held']   },
      { id: 'revenue',         label: MOTION_METRIC_LABELS['revenue'],         score: wRevTarget > 0 ? Math.min(100, Math.round((wRev / wRevTarget) * 100)) : 0,                                          status: motionMetricStatuses['revenue']         },
    ]

    const important = scores.filter(m => m.status === 'required' || m.status === 'focus')
    if (important.length === 0) return null
    return important.reduce((a, b) => a.score <= b.score ? a : b)
  }, [motionMetricStatuses, weeklyData, currentMotionStage])

  // ── Outreach / deal-flow warnings ─────────────────────────────────────────
  const motionWarnings = useMemo((): string[] => {
    const w: string[] = []
    const eSt = motionMetricStatuses['emails_sent'],  ePct = weeklyData.emailsPct ?? 0
    const cSt = motionMetricStatuses['calls_done'],   cPct = weeklyData.callsPct  ?? 0
    const dSt = motionMetricStatuses['deals_closed'], dPct = weeklyData.dealsPct  ?? 0
    if ((eSt === 'required' || eSt === 'focus') && ePct < 60)
      w.push(`Outreach low — emails at ${ePct}% this week`)
    if ((cSt === 'required' || cSt === 'focus') && cPct < 60)
      w.push(`Outreach low — calls at ${cPct}% this week`)
    if ((dSt === 'required' || dSt === 'focus') && dPct < 60)
      w.push(`Deal flow stalling — deals at ${dPct}% this week`)
    return w
  }, [motionMetricStatuses, weeklyData])

  // ── Auto priority: simple day-type-aware rules ───────────────────────────
  const autoPriority = useMemo((): AutoPriority => {
    function mk(key: PriorityKey, label: string, done: number, target: number): AutoPriority {
      return { key, label, nextAction: AUTO_NEXT_ACTIONS[key], done, target, pct: Math.min(100, Math.round(done / target * 100)), complete: done >= target }
    }
    if (isWkdayToday) {
      const cDone = todaySvc?.calls  ?? 0; const cTgt = effectiveTargets.callsPerDay
      const eDone = todaySvc?.emails ?? 0; const eTgt = effectiveTargets.emailsPerDay
      if (cDone < cTgt) return mk('calls',     'Calls',     cDone,      cTgt)
      if (eDone < eTgt) return mk('emails',    'Emails',    eDone,      eTgt)
      return                  mk('deep_work', 'Deep Work', todayDwMin, effectiveTargets.deepWorkMinPerDay)
    } else {
      const pDone = todayAmz?.productsAnalyzed ?? 0; const pTgt = effectiveTargets.productsPerDay
      if (pDone < pTgt) return mk('products',  'Products',  pDone,      pTgt)
      return                  mk('deep_work', 'Deep Work', todayDwMin, effectiveTargets.deepWorkMinPerDay)
    }
  }, [isWkdayToday, todaySvc, todayAmz, todayDwMin, effectiveTargets])

  // ── Session history ───────────────────────────────────────────────────────
  const sessionHistory = useMemo(() => {
    const past = sessions.filter(s => s.date !== today).sort((a, b) => b.date.localeCompare(a.date))
    const groups: { date: string; label: string; items: WorkSession[] }[] = []
    let cur = ''
    for (const s of past) {
      if (s.date !== cur) {
        cur = s.date
        const d = new Date(s.date + 'T12:00:00')
        groups.push({ date: s.date, label: d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }), items: [] })
      }
      groups[groups.length - 1].items.push(s)
    }
    return groups
  }, [sessions, today])

  // ── Daily score: avg of per-metric completion rates for today ────────────
  const todayScore = useMemo(() => {
    const metrics: number[] = []
    // Deep work — always tracked regardless of day type
    metrics.push(Math.min(todayDwMin / effectiveTargets.deepWorkMinPerDay, 1) * 100)
    if (isWkdayToday) {
      // Service day: emails and calls each contribute independently
      metrics.push(Math.min((todaySvc?.emails ?? 0) / effectiveTargets.emailsPerDay, 1) * 100)
      metrics.push(Math.min((todaySvc?.calls  ?? 0) / effectiveTargets.callsPerDay,  1) * 100)
    } else {
      // Amazon day: analyzed and listed each contribute independently
      metrics.push(Math.min((todayAmz?.productsAnalyzed ?? 0) / effectiveTargets.productsPerDay,       1) * 100)
      metrics.push(Math.min((todayAmz?.productsListed   ?? 0) / effectiveTargets.productsListedPerDay, 1) * 100)
    }
    return Math.round(metrics.reduce((s, v) => s + v, 0) / metrics.length)
  }, [isWkdayToday, todaySvc, todayAmz, todayDwMin, effectiveTargets])

  // ── Ineffective work: high time + low output ──────────────────────────────
  const ineffectiveWorkFlag = useMemo(() => {
    if (todayDwMin < 60) return false  // threshold: 60+ min logged
    if (isWkdayToday) {
      const inputPct = (
        (todaySvc?.emails ?? 0) / effectiveTargets.emailsPerDay +
        (todaySvc?.calls  ?? 0) / effectiveTargets.callsPerDay
      ) / 2
      return inputPct < 0.3
    } else {
      return ((todayAmz?.productsAnalyzed ?? 0) / effectiveTargets.productsPerDay) < 0.3
    }
  }, [todayDwMin, isWkdayToday, todaySvc, todayAmz, effectiveTargets])

  // ── Today priority: one metric, closest to revenue, below 80% ────────────
  const todayPriority = useMemo(() => {
    const T = 80

    // Build a result object — includes scheduling: duration, output target, intensity
    function mk(
      metric: string, rate: number, field: string,
      done: number, target: number, action: string,
      blockMax: number, blockUnit: string
    ) {
      const remaining     = Math.max(0, target - done)
      const isIncomplete  = rate < T
      const intensity     = rate < 40 ? 'high' as const : 'medium' as const
      // high deficit → longer block; low deficit → shorter block
      const blockDuration = rate < 40 ? 60 : rate < 60 ? 45 : 30
      const blockTarget   = remaining > 0 ? Math.min(blockMax, remaining) : blockMax
      return { metric, rate, field, done, target, remaining, isIncomplete, action, intensity, blockDuration, blockTarget, blockUnit }
    }

    if (isWkdayToday) {
      const eDone = todaySvc?.emails ?? 0;  const eTarget = effectiveTargets.emailsPerDay
      const cDone = todaySvc?.calls  ?? 0;  const cTarget = effectiveTargets.callsPerDay
      const emailsRate = Math.min(100, Math.round(eDone / eTarget * 100))
      const callsRate  = Math.min(100, Math.round(cDone / cTarget * 100))

      const { svc, pastWkdCount } = weeklyData
      const contacts    = svc.emails + svc.calls
      const mtgBkdTgt   = Math.max(1, Math.round(contacts * 0.10))
      const mtgHeldTgt  = Math.max(1, Math.round(svc.meetingsBooked * 0.80))
      const dealsTgt    = Math.max(1, Math.round(pastWkdCount * 0.20))
      const mtgBkdRate  = contacts           > 0 ? Math.min(100, Math.round(svc.meetingsBooked / mtgBkdTgt  * 100)) : null
      const mtgHeldRate = svc.meetingsBooked > 0 ? Math.min(100, Math.round(svc.meetingsHeld   / mtgHeldTgt * 100)) : null
      const dealsRate   = weeklyData.dealsPct

      // Waterfall — closest to revenue first
      if (dealsRate   !== null && dealsRate   < T) return mk('Deals',           dealsRate,   'deals',          svc.deals,          dealsTgt,   'Follow up on held meetings. Close.',        1,  'deal'           )
      if (mtgHeldRate !== null && mtgHeldRate < T) return mk('Meetings held',   mtgHeldRate, 'meetingsHeld',   svc.meetingsHeld,   mtgHeldTgt, 'Reach out to booked contacts. Hold the call.', 1, 'meeting held'  )
      if (mtgBkdRate  !== null && mtgBkdRate  < T) return mk('Meetings booked', mtgBkdRate,  'meetingsBooked', svc.meetingsBooked, mtgBkdTgt,  'Follow up / book calls',                    1,  'meeting booked')
      if (callsRate   < T) return mk('Calls',  callsRate,  'calls',  cDone, cTarget, `Make ${Math.min(3,  Math.max(1, cTarget - cDone))} calls`,   3,  'calls'  )
      if (emailsRate  < T) return mk('Emails', emailsRate, 'emails', eDone, eTarget, `Send ${Math.min(10, Math.max(1, eTarget - eDone))} emails`,  10, 'emails' )
      return null

    } else {
      const aDone = todayAmz?.productsAnalyzed ?? 0;  const aTarget = effectiveTargets.productsPerDay
      const lDone = todayAmz?.productsListed   ?? 0;  const lTarget = effectiveTargets.productsListedPerDay
      const analyzedRate = Math.min(100, Math.round(aDone / aTarget * 100))
      const listedRate   = Math.min(100, Math.round(lDone / lTarget * 100))

      const { amz } = weeklyData
      const ordersTgt  = Math.max(1, Math.round(weeklyData.pastWkeCount * 0.50))
      const ordersRate = amz.productsListed > 0 ? Math.min(100, Math.round(amz.orders / (amz.productsListed * 0.10) * 100)) : null

      // Waterfall — closest to revenue first
      if (ordersRate   !== null && ordersRate   < T) return mk('Orders',             ordersRate,   'orders',           amz.orders, ordersTgt, 'Review listings. Drive sales.',                         1,  'order'   )
      if (listedRate   < T) return mk('Products listed',   listedRate,   'productsListed',   lDone, lTarget, `List ${Math.min(5,  Math.max(1, lTarget - lDone))} products`,    5,  'listings')
      if (analyzedRate < T) return mk('Products analyzed', analyzedRate, 'productsAnalyzed', aDone, aTarget, `Analyze ${Math.min(10, Math.max(1, aTarget - aDone))} products`, 10, 'products')
      return null
    }
  }, [isWkdayToday, todaySvc, todayAmz, weeklyData, effectiveTargets])

  // ── Anti-escape: score penalty + warning ──────────────────────────────────
  const priorityIncomplete = todayPriority !== null && todayPriority.rate < 80
  const displayScore       = priorityIncomplete ? Math.round(todayScore * 0.5) : todayScore
  const scoreWarning       = priorityIncomplete

  // ── Log functions ─────────────────────────────────────────────────────────
  function logSvc(field: keyof Omit<ServiceRecord, 'date'>, amount = 1) {
    // Compute next record now (for Supabase sync) — safe at point-of-click
    const current = serviceLog.find(r => r.date === today) ?? blankSvc(today)
    const next: ServiceRecord = { ...current, [field]: Math.max(0, (current[field] as number) + amount) }

    // Optimistic local update
    setServiceLog(prev => {
      const rec     = prev.find(r => r.date === today) ?? blankSvc(today)
      const updated = [...prev.filter(r => r.date !== today), { ...rec, [field]: (rec[field] as number) + amount }]
      lsSet(LS_SVC, updated); return updated
    })

    // Persist to Supabase
    if (user) {
      supabase
        .from('service_records')
        .upsert({
          user_id:         user.id,
          record_date:     today,
          emails:          next.emails,
          calls:           next.calls,
          meetings_booked: next.meetingsBooked,
          meetings_held:   next.meetingsHeld,
          deals:           next.deals,
          revenue:         next.revenue,
        }, { onConflict: 'user_id,record_date' })
        .then(({ error }) => { if (error) console.error('[motion] upsert service_records:', error) })
    }
  }
  function logSvcRevenue() {
    const n = parseFloat(svcRevInput); if (isNaN(n) || n <= 0) return
    logSvc('revenue', n); setSvcRevInput('')
  }
  function logAmz(field: keyof Omit<AmazonRecord, 'date'>, amount = 1) {
    const current = amazonLog.find(r => r.date === today) ?? blankAmz(today)
    const next: AmazonRecord = { ...current, [field]: Math.max(0, (current[field] as number) + amount) }

    setAmazonLog(prev => {
      const rec     = prev.find(r => r.date === today) ?? blankAmz(today)
      const updated = [...prev.filter(r => r.date !== today), { ...rec, [field]: (rec[field] as number) + amount }]
      lsSet(LS_AMZ, updated); return updated
    })

    if (user) {
      supabase
        .from('amazon_records')
        .upsert({
          user_id:           user.id,
          record_date:       today,
          products_analyzed: next.productsAnalyzed,
          products_listed:   next.productsListed,
          orders_count:      next.orders,
          revenue:           next.revenue,
        }, { onConflict: 'user_id,record_date' })
        .then(({ error }) => { if (error) console.error('[motion] upsert amazon_records:', error) })
    }
  }
  function logAmzRevenue() {
    const n = parseFloat(amzRevInput); if (isNaN(n) || n <= 0) return
    logAmz('revenue', n); setAmzRevInput('')
  }
  function logSession() {
    if (sessionForm.minutes <= 0) return
    const s: WorkSession = {
      id:         `${today}-${Date.now()}`,
      date:       today,
      type:       sessionForm.type,
      category:   sessionForm.category,
      isDeepWork: sessionForm.isDeepWork,
      minutes:    sessionForm.minutes,
      note:       sessionForm.note.trim(),
    }
    setSessions(prev => { const u = [...prev, s]; lsSet(LS_SESSIONS, u); return u })
    setSessionForm(f => ({ ...f, minutes: 30, note: '', isDeepWork: false }))

    if (user) {
      supabase
        .from('work_sessions')
        .insert({
          user_id:      user.id,
          session_date: today,
          type:         s.type,
          category:     s.category,
          is_deep_work: s.isDeepWork,
          minutes:      s.minutes,
          note:         s.note,
        })
        .then(({ error }) => { if (error) console.error('[motion] insert work_sessions:', error) })
    }
  }

  // ── Execution settings save — persist to Supabase then update App state ──
  function handleSaveSettings(updated: ExecutionSettings) {
    onSaveSettings(updated)
    if (user) {
      supabase
        .from('execution_settings')
        .upsert({
          user_id:               user.id,
          emails_per_day:        updated.emailsPerDay,
          calls_per_day:         updated.callsPerDay,
          products_per_day:      updated.productsPerDay,
          deep_work_min_per_day: updated.deepWorkMinPerDay,
        }, { onConflict: 'user_id' })
        .then(({ error }) => { if (error) console.error('[motion] upsert execution_settings:', error) })
    }
  }

  // ── Shared sub-component ──────────────────────────────────────────────────
  function PctCard({ label, pct }: { label: string; pct: number | null }) {
    return (
      <div className="rounded-lg border border-white/8 bg-white/3 px-3 py-2.5 flex flex-col gap-1.5">
        <span className="text-[9px] text-white/50 uppercase tracking-widest">{label}</span>
        <span className={`text-base font-black tabular-nums leading-none ${
          pct === null ? 'text-white/45' : pct >= 80 ? 'text-emerald-400/80' : pct >= 50 ? 'text-amber-400/80' : 'text-red-400/80'
        }`}>{pct !== null ? `${pct}%` : '—'}</span>
        <div className="h-0.5 bg-white/8 rounded-full overflow-hidden">
          <div className={`h-full rounded-full ${
            pct === null ? 'bg-white/12' : pct >= 80 ? 'bg-emerald-500/55' : pct >= 50 ? 'bg-amber-400/55' : 'bg-red-500/55'
          }`} style={{ width: `${pct ?? 0}%` }} />
        </div>
      </div>
    )
  }

  function DefRow({ label, done, target, isTime }: { label: string; done: number; target: number; isTime?: boolean }) {
    const remaining = Math.max(0, target - done)
    const hit = remaining === 0
    const pct = target > 0 ? Math.min(100, Math.round((done / target) * 100)) : 0
    const doneStr = isTime ? fmtMin(done) : String(done)
    const tgtStr  = isTime ? fmtMin(target) : String(target)
    const remStr  = isTime ? `${fmtMin(remaining)} left` : `${remaining} left`
    return (
      <div className="py-3 flex flex-col gap-1.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${hit ? 'bg-emerald-500' : 'bg-red-500/60'}`} />
            <span className={`text-sm font-semibold ${hit ? 'text-emerald-400/70' : 'text-white/70'}`}>{label}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-white/35">{doneStr} / {tgtStr}</span>
            {hit
              ? <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded border border-emerald-500/20 bg-emerald-500/8 text-emerald-400/60">Done</span>
              : <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded border border-red-500/20 bg-red-500/8 text-red-400/65">{remStr}</span>
            }
          </div>
        </div>
        <div className="h-0.5 bg-white/8 rounded-full overflow-hidden">
          <div className={`h-full rounded-full transition-all ${hit ? 'bg-emerald-500/50' : 'bg-red-500/35'}`} style={{ width: `${pct}%` }} />
        </div>
      </div>
    )
  }

  function PipeBar({ label, done, target }: { label: string; done: number; target: number }) {
    const pct = target > 0 ? Math.min(100, Math.round((done / target) * 100)) : 0
    const hit = done >= target
    return (
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between">
          <span className="text-xs text-white/50">{label}</span>
          <span className={`text-xs font-mono tabular-nums ${hit ? 'text-emerald-400/70' : 'text-white/55'}`}>{done.toLocaleString()} / {target.toLocaleString()}</span>
        </div>
        <div className="h-1 bg-white/8 rounded-full overflow-hidden">
          <div className={`h-full rounded-full transition-all ${hit ? 'bg-emerald-500/60' : 'bg-emerald-500/30'}`} style={{ width: `${pct}%` }} />
        </div>
      </div>
    )
  }

  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col gap-4">
      <FlowPageHeader title="Motion" subtitle="Revenue & outreach engine" badge="dominant" />
      <FlowTabs tabs={TABS} active={activeTab} onChange={setActiveTab} accent="emerald" />

      {/* ── OVERVIEW ────────────────────────────────────────────────────── */}
      {activeTab === 'overview' && (
        <div className="flex flex-col gap-4">

          {/* Revenue — current month only (stage validation window) */}
          <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">This Month's Revenue</span>
              <span className="text-xs text-emerald-400/60 font-mono">{revPct}% of ${STAGE_REVENUE.toLocaleString()}</span>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'Service', val: currentMonthRev.svc   },
                { label: 'Amazon',  val: currentMonthRev.amz   },
                { label: 'Total',   val: currentMonthRev.total  },
              ].map(item => (
                <div key={item.label} className="flex flex-col gap-0.5">
                  <span className="text-[9px] text-white/50 uppercase tracking-widest">{item.label}</span>
                  <span className={`text-lg font-bold tabular-nums ${item.label === 'Total' ? 'text-white/65' : 'text-emerald-400'}`}>
                    ${item.val.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
            <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500/60 rounded-full transition-all" style={{ width: `${revPct}%` }} />
            </div>
            <span className="text-[9px] text-white/50 text-right">${Math.max(0, STAGE_REVENUE - currentMonthRev.total).toLocaleString()} remaining to $3,000 this month</span>
          </div>

          {/* Revenue History */}
          {revenueHistory.length > 0 && (
            <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-white/55 uppercase tracking-widest font-semibold">Revenue History</span>
                <span className="text-[10px] text-white/50 font-mono tabular-nums">
                  All-time: ${stageTotals.totalRevenue.toLocaleString()}
                </span>
              </div>
              <div className="flex flex-col gap-1">
                {revenueHistory.map(m => {
                  const barPct = revenueHistory[0].rev > 0
                    ? Math.round((m.rev / revenueHistory[0].rev) * 100)
                    : 0
                  return (
                    <div key={m.key} className="flex items-center gap-3">
                      <span className={`text-[10px] w-20 shrink-0 ${m.isCurrent ? 'text-white/55 font-semibold' : 'text-white/55'}`}>
                        {m.label}
                      </span>
                      <div className="flex-1 h-1 bg-white/8 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${m.isCurrent ? 'bg-emerald-500/50' : 'bg-white/20'}`}
                          style={{ width: `${barPct}%` }}
                        />
                      </div>
                      <span className={`text-[10px] font-mono tabular-nums w-16 text-right shrink-0 ${m.isCurrent ? 'text-emerald-400/80 font-bold' : 'text-white/35'}`}>
                        ${m.rev.toLocaleString()}
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* Motion Stage card */}
          {(() => {
            const stage    = currentMotionStage
            const next     = nextMotionStage
            const progress = motionStageProgress
            return (
              <div className="rounded-xl border border-emerald-500/18 bg-white/5 p-5 flex flex-col gap-3.5">
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] text-white/55 uppercase tracking-widest font-semibold">
                      Stage {stage.id} · Motion
                    </span>
                    <p className="text-base font-black text-white leading-tight mt-0.5">{stage.name}</p>
                    {next
                      ? <p className="text-xs text-white/35 mt-0.5">Next: {next.name} at ${next.revenueThreshold.toLocaleString()}{next.consistencyMonths > 0 ? `/mo × ${next.consistencyMonths}` : ' total'}</p>
                      : <p className="text-xs text-white/50 mt-0.5">Final stage</p>
                    }
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-emerald-500/25 bg-emerald-500/8 shrink-0">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                    <span className="text-[10px] font-bold text-emerald-400">Active</span>
                  </div>
                </div>

                {/* Stage progress */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex justify-between items-baseline text-[10px] font-mono">
                    <span className="text-white/35">{progress.progressLabel}</span>
                    <span className="text-white/45">{progress.contextLabel}</span>
                  </div>
                  <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${progress.pct >= 100 ? 'bg-emerald-500/60' : 'bg-emerald-500/35'}`}
                      style={{ width: `${progress.pct}%` }}
                    />
                  </div>
                  <div className="flex justify-end">
                    <span className={`text-[10px] font-semibold font-mono ${progress.pct >= 100 ? 'text-emerald-400' : 'text-white/50'}`}>
                      {progress.pct}%
                    </span>
                  </div>
                </div>

                {/* Metric statuses */}
                <div className="flex flex-col gap-2 pt-1 border-t border-white/6">
                  <span className="text-[9px] text-white/45 uppercase tracking-widest font-semibold">
                    Metric priority — Stage {stage.id}
                  </span>
                  {/* Service track */}
                  <span className="text-[8px] text-white/42 uppercase tracking-widest">Service</span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(['emails_sent', 'calls_done', 'meetings_booked', 'meetings_held', 'deals_closed', 'revenue'] as const).map(id => {
                      const st  = motionMetricStatuses[id]
                      const cfg = MOTION_STATUS_CFG[st]
                      // Stage 1: show cumulative numeric progress for required metrics
                      const stage1Num: Partial<Record<typeof id, { value: number; target: number }>> = stage.id === 1 ? {
                        emails_sent:  { value: stageTotals.svc.emails, target: STAGE_SVC_EMAILS },
                        calls_done:   { value: stageTotals.svc.calls,  target: STAGE_SVC_CALLS  },
                        deals_closed: { value: stageTotals.svc.deals,  target: STAGE_SVC_DEALS  },
                      } : {}
                      const num = stage1Num[id]
                      return (
                        <div key={id} className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border ${cfg.bg} ${cfg.border}`}>
                          <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${cfg.dot}`} />
                          <div className="flex flex-col leading-none gap-0.5 min-w-0">
                            <span className={`text-[10px] font-semibold truncate ${cfg.text}`}>{MOTION_METRIC_LABELS[id]}</span>
                            {num
                              ? <span className={`text-[9px] font-mono font-bold tabular-nums ${num.value >= num.target ? 'text-emerald-400/80' : cfg.text}`}>
                                  {num.value.toLocaleString()} / {num.target.toLocaleString()}
                                </span>
                              : <span className="text-[8px] text-white/42 uppercase tracking-wide">{cfg.label}</span>
                            }
                          </div>
                        </div>
                      )
                    })}
                  </div>
                  {/* Amazon track */}
                  <span className="text-[8px] text-white/42 uppercase tracking-widest mt-1">Amazon</span>
                  <div className="grid grid-cols-3 gap-1.5">
                    {[
                      { label: 'Analyzed', value: stageTotals.amz.productsAnalyzed },
                      { label: 'Listed',   value: stageTotals.amz.productsListed   },
                      { label: 'Orders',   value: stageTotals.amz.orders            },
                    ].map(item => (
                      <div key={item.label} className="flex flex-col gap-0.5 px-2.5 py-1.5 rounded-lg border border-white/6 bg-white/3">
                        <span className="text-[8px] text-white/45 uppercase tracking-widest">{item.label}</span>
                        <span className="text-sm font-bold text-white/50 tabular-nums">{item.value.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )
          })()}

          {/* Today Priority + Next Action */}
          {(() => {
            const p    = autoPriority
            const done = p.complete
            return (
              <div className={`rounded-xl border p-4 flex flex-col gap-3 ${
                done ? 'border-emerald-500/20 bg-emerald-500/4' : 'border-white/10 bg-white/5'
              }`}>
                {/* Header */}
                <div className="flex items-center justify-between">
                  <span className="text-[9px] text-white/55 uppercase tracking-widest font-semibold">Today Priority</span>
                  <span className={`text-[9px] font-semibold px-2 py-0.5 rounded-full border ${
                    isWkdayToday
                      ? 'border-blue-500/15 bg-blue-500/8 text-blue-400/60'
                      : 'border-amber-500/15 bg-amber-500/8 text-amber-400/60'
                  }`}>{isWkdayToday ? 'Service' : 'Amazon'}</span>
                </div>

                {/* Priority metric + progress */}
                <div className="flex items-center justify-between">
                  <span className={`text-sm font-bold ${done ? 'text-emerald-400/80' : 'text-white/85'}`}>{p.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-white/55">{p.done} / {p.target}</span>
                    <span className={`text-xs font-black tabular-nums ${
                      p.pct >= 100 ? 'text-emerald-400/80'
                      : p.pct >= 60 ? 'text-amber-400/75'
                      : 'text-red-400/75'
                    }`}>{p.pct}%</span>
                  </div>
                </div>
                <div className="h-1 bg-white/8 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full transition-all ${
                    p.pct >= 100 ? 'bg-emerald-500/60'
                    : p.pct >= 60 ? 'bg-amber-400/50'
                    : 'bg-red-500/50'
                  }`} style={{ width: `${p.pct}%` }} />
                </div>

                {/* Next Action */}
                <div className="flex items-center gap-2.5 pt-1 border-t border-white/6">
                  <span className="text-[9px] text-white/45 uppercase tracking-widest shrink-0">Next action</span>
                  <span className={`text-xs font-semibold ${done ? 'text-emerald-400/65' : 'text-white/70'}`}>
                    {done ? 'Target met — stay consistent.' : p.nextAction}
                  </span>
                </div>

                {/* Score penalty */}
                {scoreWarning && (
                  <div className="flex items-center gap-1.5 pt-0.5 border-t border-red-500/10">
                    <span className="text-[9px] font-semibold text-red-400/55">Score −50%</span>
                    <span className="text-[9px] text-white/45">·</span>
                    <span className="text-[9px] text-white/55">Priority not yet met</span>
                  </div>
                )}
              </div>
            )
          })()}

          {/* Today's snapshot + deficit */}
          <div className="rounded-xl border border-white/10 bg-white/5 px-4 divide-y divide-white/5">
            <div className="flex items-center justify-between py-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Today's Deficit</span>
                {effectiveTargets.anyAdapted && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded border border-purple-500/20 bg-purple-500/8 text-purple-400/60 font-semibold">Adapted</span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono tabular-nums font-semibold ${
                  displayScore >= 70 ? 'text-emerald-400/65' : displayScore >= 40 ? 'text-amber-400/65' : 'text-red-400/65'
                }`}>{displayScore}%</span>
                <span className={`text-[9px] font-semibold px-2 py-0.5 rounded-full border ${
                  isWkdayToday ? 'border-blue-500/15 bg-blue-500/8 text-blue-400/60' : 'border-amber-500/15 bg-amber-500/8 text-amber-400/60'
                }`}>{isWkdayToday ? 'Service day' : 'Amazon day'}</span>
              </div>
            </div>
            <DefRow label="Deep Work" done={todayDwMin} target={effectiveTargets.deepWorkMinPerDay} isTime />
            {isWkdayToday ? (
              <>
                <DefRow label="Emails" done={todaySvc?.emails ?? 0} target={effectiveTargets.emailsPerDay} />
                <DefRow label="Calls"  done={todaySvc?.calls  ?? 0} target={effectiveTargets.callsPerDay}  />
              </>
            ) : (
              <>
                <DefRow label="Products analyzed" done={todayAmz?.productsAnalyzed ?? 0} target={effectiveTargets.productsPerDay} />
                <DefRow label="Products listed"   done={todayAmz?.productsListed   ?? 0} target={effectiveTargets.productsListedPerDay} />
              </>
            )}
          </div>

        </div>
      )}

      {/* ── DEEP WORK ───────────────────────────────────────────────────── */}
      {activeTab === 'deep-work' && (
        <div className="flex flex-col gap-4">
          <ExecutionSettingsCard settings={settings} onSave={handleSaveSettings} />

          {ineffectiveWorkFlag && (
            <div className="flex items-start gap-2.5 px-3 py-2.5 rounded-lg border border-amber-500/20 bg-amber-500/6">
              <span className="text-amber-400/60 text-sm shrink-0 mt-px">⚠</span>
              <div>
                <span className="text-xs font-semibold text-amber-400/70">Ineffective work detected</span>
                <p className="text-[10px] text-white/35 mt-0.5 leading-relaxed">High session time logged but output is below 30% of today's targets. Redirect focus toward inputs.</p>
              </div>
            </div>
          )}

          {/* Log session form */}
          <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-4">
            <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Log Session</span>

            <div className="flex flex-col gap-2">
              <span className="text-[10px] text-white/55 uppercase tracking-widest">Type</span>
              <div className="flex gap-2">
                {(['service', 'amazon'] as const).map(t => (
                  <button key={t} onClick={() => setSessionForm(f => ({
                    ...f, type: t,
                    category: t === 'service' ? 'outreach' : 'product-analysis'
                  }))}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors capitalize ${
                      sessionForm.type === t ? 'border-emerald-500/30 bg-emerald-500/12 text-emerald-400' : 'border-white/10 text-white/35 hover:text-white/55 bg-white/3'
                    }`}>{t}</button>
                ))}
              </div>
            </div>

            {/* Deep Work toggle */}
            <button
              onClick={() => setSessionForm(f => ({ ...f, isDeepWork: !f.isDeepWork }))}
              className={`flex items-center justify-between px-3 py-2.5 rounded-lg border text-xs font-semibold transition-colors ${
                sessionForm.isDeepWork
                  ? 'border-blue-500/30 bg-blue-500/10 text-blue-400'
                  : 'border-white/10 bg-white/3 text-white/35 hover:text-white/55'
              }`}>
              <span>Deep Work</span>
              <span className={`w-3.5 h-3.5 rounded-full border-2 transition-colors ${
                sessionForm.isDeepWork ? 'bg-blue-400 border-blue-400' : 'border-white/25 bg-transparent'
              }`} />
            </button>

            <div className="flex flex-col gap-2">
              <span className="text-[10px] text-white/55 uppercase tracking-widest">Category</span>
              <div className="flex flex-wrap gap-2">
                {(sessionForm.type === 'service' ? SVC_CATS : AMZ_CATS).map(c => (
                  <button key={c} onClick={() => setSessionForm(f => ({ ...f, category: c }))}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${
                      sessionForm.category === c ? 'border-emerald-500/30 bg-emerald-500/12 text-emerald-400' : 'border-white/10 text-white/35 hover:text-white/55 bg-white/3'
                    }`}>{CAT_LABEL[c]}</button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <span className="text-[10px] text-white/55 uppercase tracking-widest">Duration</span>
              <div className="flex gap-2">
                {[15, 30, 45, 60, 90].map(m => (
                  <button key={m} onClick={() => setSessionForm(f => ({ ...f, minutes: m }))}
                    className={`flex-1 py-2 rounded-lg border text-xs font-semibold transition-colors ${
                      sessionForm.minutes === m ? 'border-emerald-500/30 bg-emerald-500/12 text-emerald-400' : 'border-white/8 text-white/55 hover:text-white/50 bg-white/3'
                    }`}>{m}m</button>
                ))}
              </div>
              <input type="number" min={1} max={480} value={sessionForm.minutes}
                onChange={e => setSessionForm(f => ({ ...f, minutes: Math.max(1, parseInt(e.target.value) || 1) }))}
                className="w-24 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-white/20 transition-colors"
                placeholder="min" />
            </div>

            <div className="flex flex-col gap-2">
              <span className="text-[10px] text-white/55 uppercase tracking-widest">Note (optional)</span>
              <input type="text" value={sessionForm.note}
                onChange={e => setSessionForm(f => ({ ...f, note: e.target.value }))}
                placeholder="What did you work on?"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/20 transition-colors" />
            </div>

            <button onClick={logSession}
              className="w-full py-2.5 rounded-lg border border-emerald-500/25 bg-emerald-500/10 text-emerald-400 text-sm font-semibold hover:bg-emerald-500/18 transition-colors">
              Log Session — {fmtMin(sessionForm.minutes)}
            </button>
          </div>

          {/* Today's sessions */}
          {todaySessions.length > 0 && (
            <div className="rounded-xl border border-white/10 bg-white/5 px-4 divide-y divide-white/5">
              <div className="flex items-center justify-between py-3">
                <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Today</span>
                <span className="text-xs font-mono text-white/55">{fmtMin(todayDwMin)} total</span>
              </div>
              {todaySessions.map(s => (
                <div key={s.id} className="flex items-center gap-3 py-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-white/65 capitalize">{s.type}</span>
                      <span className="text-[9px] text-white/50">·</span>
                      <span className="text-xs text-white/40">{CAT_LABEL[s.category]}</span>
                      {s.isDeepWork && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded border border-blue-500/25 bg-blue-500/8 text-blue-400/70 font-semibold">DW</span>
                      )}
                    </div>
                    {s.note && <p className="text-[10px] text-white/50 mt-0.5 truncate">{s.note}</p>}
                  </div>
                  <span className="text-xs font-mono text-white/45 shrink-0">{fmtMin(s.minutes)}</span>
                </div>
              ))}
            </div>
          )}

          {/* History */}
          {sessionHistory.length > 0 && (
            <div className="flex flex-col gap-3">
              <span className="text-[10px] text-white/50 uppercase tracking-widest font-semibold px-1">History</span>
              {sessionHistory.slice(0, 7).map(group => (
                <div key={group.date} className="rounded-xl border border-white/8 bg-white/3 px-4 divide-y divide-white/4">
                  <div className="flex items-center justify-between py-2.5">
                    <span className="text-[10px] text-white/35 font-semibold">{group.label}</span>
                    <span className="text-[10px] font-mono text-white/50">{fmtMin(group.items.reduce((s, r) => s + r.minutes, 0))}</span>
                  </div>
                  {group.items.map(s => (
                    <div key={s.id} className="flex items-center gap-3 py-2.5">
                      <span className="text-xs text-white/45 capitalize">{s.type}</span>
                      <span className="text-[9px] text-white/45">·</span>
                      <span className="text-[10px] text-white/55">{CAT_LABEL[s.category]}</span>
                      {s.isDeepWork && (
                        <span className="text-[9px] px-1 py-px rounded border border-blue-500/20 bg-blue-500/6 text-blue-400/60 font-semibold">DW</span>
                      )}
                      {s.note && <span className="text-[10px] text-white/45 flex-1 truncate">{s.note}</span>}
                      <span className="text-[10px] font-mono text-white/35 ml-auto shrink-0">{fmtMin(s.minutes)}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── PIPELINE ────────────────────────────────────────────────────── */}
      {activeTab === 'pipeline' && (
        <div className="flex flex-col gap-4">

          {/* Toggle */}
          <div className="flex rounded-lg border border-white/10 overflow-hidden">
            {(['service', 'amazon'] as const).map(v => (
              <button key={v} onClick={() => setPipeView(v)}
                className={`flex-1 py-2.5 text-xs font-semibold transition-colors ${
                  pipeView === v ? 'bg-white/10 text-white' : 'text-white/35 hover:text-white/55 hover:bg-white/5'
                }`}>
                {v === 'service' ? 'Service — weekdays' : 'Amazon — weekends'}
              </button>
            ))}
          </div>

          {/* ── SERVICE PIPELINE ── */}
          {pipeView === 'service' && (() => {
            return (
            <div className="flex flex-col gap-4">

              {/* Inputs */}
              <div className="rounded-xl border border-white/10 bg-white/5 px-4 divide-y divide-white/5">
                <div className="py-3"><span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Inputs</span></div>
                {([
                  { label: 'Emails sent', done: todaySvc?.emails ?? 0, target: effectiveTargets.emailsPerDay, field: 'emails' as const },
                  { label: 'Calls made',  done: todaySvc?.calls  ?? 0, target: effectiveTargets.callsPerDay,  field: 'calls'  as const },
                ] as const).map(row => {
                  const hit      = row.done >= row.target
                  const isPrior  = todayPriority?.field === row.field
                  return (
                    <div key={row.label} className={`flex items-center gap-3 py-3.5 ${isPrior ? '-mx-4 px-4 bg-amber-500/6 border-l-2 border-amber-400/40' : ''}`}>
                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${hit ? 'bg-emerald-500' : row.done > 0 ? 'bg-amber-400/60' : 'bg-white/15'}`} />
                      <div className="flex-1 flex items-center gap-2">
                        <span className={`text-sm font-semibold ${hit ? 'text-emerald-400/70' : 'text-white/70'}`}>{row.label}</span>
                        <span className="text-[9px] text-white/45">target {row.target}</span>
                        {isPrior && <span className="text-[9px] px-1.5 py-0.5 rounded border border-amber-500/25 bg-amber-500/10 text-amber-400/70 font-semibold">Priority</span>}
                      </div>
                      <span className={`text-sm font-bold tabular-nums ${hit ? 'text-emerald-400/70' : row.done > 0 ? 'text-white/55' : 'text-white/50'}`}>
                        {row.done}/{row.target}
                      </span>
                      <div className="flex items-center gap-1 shrink-0">
                        <button onClick={() => logSvc(row.field, -1)} disabled={row.done <= 0}
                          className="px-2.5 py-1.5 rounded-lg border border-white/12 text-white/35 bg-white/4 text-xs font-semibold hover:bg-white/8 disabled:opacity-30 transition-colors">
                          −1
                        </button>
                        <button onClick={() => logSvc(row.field)}
                          className="px-2.5 py-1.5 rounded-lg border border-emerald-500/25 text-emerald-400/70 bg-emerald-500/8 text-xs font-semibold hover:bg-emerald-500/15 transition-colors">
                          +1
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* Flow */}
              <div className="rounded-xl border border-white/10 bg-white/5 px-4 divide-y divide-white/5">
                <div className="py-3"><span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Flow</span></div>
                {([
                  { label: 'Meetings booked', done: todaySvc?.meetingsBooked ?? 0, field: 'meetingsBooked' as const },
                  { label: 'Meetings held',   done: todaySvc?.meetingsHeld   ?? 0, field: 'meetingsHeld'   as const },
                  { label: 'Deals closed',    done: todaySvc?.deals           ?? 0, field: 'deals'          as const },
                ] as const).map(row => {
                  const isPrior = todayPriority?.field === row.field
                  return (
                    <div key={row.label} className={`flex items-center gap-3 py-3.5 ${isPrior ? '-mx-4 px-4 bg-amber-500/6 border-l-2 border-amber-400/40' : ''}`}>
                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${row.done > 0 ? 'bg-emerald-500' : 'bg-white/15'}`} />
                      <div className="flex-1 flex items-center gap-2">
                        <span className={`text-sm font-semibold ${row.done > 0 ? 'text-emerald-400/70' : 'text-white/70'}`}>{row.label}</span>
                        {isPrior && <span className="text-[9px] px-1.5 py-0.5 rounded border border-amber-500/25 bg-amber-500/10 text-amber-400/70 font-semibold">Priority</span>}
                      </div>
                      <span className={`text-sm font-bold tabular-nums ${row.done > 0 ? 'text-emerald-400/70' : 'text-white/50'}`}>{row.done}</span>
                      <div className="flex items-center gap-1 shrink-0">
                        <button onClick={() => logSvc(row.field, -1)} disabled={row.done <= 0}
                          className="px-2.5 py-1.5 rounded-lg border border-white/12 text-white/35 bg-white/4 text-xs font-semibold hover:bg-white/8 disabled:opacity-30 transition-colors">
                          −1
                        </button>
                        <button onClick={() => logSvc(row.field)}
                          className="px-2.5 py-1.5 rounded-lg border border-emerald-500/25 text-emerald-400/70 bg-emerald-500/8 text-xs font-semibold hover:bg-emerald-500/15 transition-colors">
                          +1
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* Revenue */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-3">
                <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Revenue</span>
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-lg border border-white/8 bg-white/3 px-3 py-2.5 flex flex-col gap-0.5">
                    <span className="text-[9px] text-white/50 uppercase tracking-widest">Today</span>
                    <span className="text-lg font-bold text-emerald-400">${(todaySvc?.revenue ?? 0).toLocaleString()}</span>
                  </div>
                  <div className="rounded-lg border border-white/8 bg-white/3 px-3 py-2.5 flex flex-col gap-0.5">
                    <span className="text-[9px] text-white/50 uppercase tracking-widest">Cumulative</span>
                    <span className="text-lg font-bold text-white/55">${stageTotals.svc.revenue.toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <input type="number" step={0.01} value={svcRevInput}
                    onChange={e => setSvcRevInput(e.target.value)} placeholder="Amount ($)"
                    className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/20 transition-colors" />
                  <button onClick={logSvcRevenue}
                    className="px-3 py-2 rounded-lg border border-emerald-500/25 bg-emerald-500/8 text-emerald-400/70 text-sm font-semibold hover:bg-emerald-500/15 transition-colors shrink-0">
                    +Add
                  </button>
                  <button
                    onClick={() => {
                      const n = parseFloat(svcRevInput)
                      if (isNaN(n) || n < 0) return
                      logSvc('revenue', n - (todaySvc?.revenue ?? 0))
                      setSvcRevInput('')
                    }}
                    className="px-3 py-2 rounded-lg border border-white/12 bg-white/4 text-white/40 text-sm font-semibold hover:bg-white/8 transition-colors shrink-0">
                    Set
                  </button>
                </div>
              </div>

              {/* Conversions */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-3">
                <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Conversion (this week)</span>
                <div className="flex flex-col gap-2">
                  {[
                    { label: 'Email + Call → Meeting booked', pct: weeklyData.emailCallToMtg, a: weeklyData.svc.meetingsBooked, b: weeklyData.svc.emails + weeklyData.svc.calls },
                    { label: 'Meeting booked → Meeting held', pct: weeklyData.mtgBookedHeld,  a: weeklyData.svc.meetingsHeld,   b: weeklyData.svc.meetingsBooked               },
                    { label: 'Meeting held → Deal closed',    pct: weeklyData.mtgHeldDeal,    a: weeklyData.svc.deals,           b: weeklyData.svc.meetingsHeld                 },
                  ].map(c => (
                    <div key={c.label} className="flex items-center justify-between px-3 py-2.5 rounded-lg border border-white/8 bg-white/3">
                      <div>
                        <span className="text-xs text-white/50">{c.label}</span>
                        <span className="text-[9px] text-white/45 ml-2">{c.a} / {c.b}</span>
                      </div>
                      <span className={`text-sm font-black tabular-nums ml-3 shrink-0 ${
                        c.pct === null ? 'text-white/45' : c.pct >= 20 ? 'text-emerald-400' : c.pct >= 10 ? 'text-amber-400' : 'text-red-400'
                      }`}>{c.pct !== null ? `${c.pct}%` : '—'}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Stage progress */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-4">
                <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Stage Progress</span>
                <PipeBar label="Emails" done={stageTotals.svc.emails} target={STAGE_SVC_EMAILS} />
                <PipeBar label="Calls"  done={stageTotals.svc.calls}  target={STAGE_SVC_CALLS}  />
                <PipeBar label="Deals"  done={stageTotals.svc.deals}  target={STAGE_SVC_DEALS}  />
              </div>
            </div>
            )
          })()}

          {/* ── AMAZON PIPELINE ── */}
          {pipeView === 'amazon' && (() => {
            return (
            <div className="flex flex-col gap-4">

              {/* Inputs */}
              <div className="rounded-xl border border-white/10 bg-white/5 px-4 divide-y divide-white/5">
                <div className="py-3"><span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Inputs</span></div>
                {(() => {
                  const done    = todayAmz?.productsAnalyzed ?? 0
                  const target  = effectiveTargets.productsPerDay
                  const hit     = done >= target
                  const isPrior = todayPriority?.field === 'productsAnalyzed'
                  return (
                    <div className={`flex items-center gap-3 py-3.5 ${isPrior ? '-mx-4 px-4 bg-amber-500/6 border-l-2 border-amber-400/40' : ''}`}>
                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${hit ? 'bg-emerald-500' : done > 0 ? 'bg-amber-400/60' : 'bg-white/15'}`} />
                      <div className="flex-1 flex items-center gap-2">
                        <span className={`text-sm font-semibold ${hit ? 'text-emerald-400/70' : 'text-white/70'}`}>Products analyzed</span>
                        <span className="text-[9px] text-white/45">target {target}</span>
                        {isPrior && <span className="text-[9px] px-1.5 py-0.5 rounded border border-amber-500/25 bg-amber-500/10 text-amber-400/70 font-semibold">Priority</span>}
                      </div>
                      <span className={`text-sm font-bold tabular-nums ${hit ? 'text-emerald-400/70' : done > 0 ? 'text-white/55' : 'text-white/50'}`}>{done}/{target}</span>
                      <div className="flex items-center gap-1 shrink-0">
                        <button onClick={() => logAmz('productsAnalyzed', -1)} disabled={done <= 0}
                          className="px-2.5 py-1.5 rounded-lg border border-white/12 text-white/35 bg-white/4 text-xs font-semibold hover:bg-white/8 disabled:opacity-30 transition-colors">
                          −1
                        </button>
                        <button onClick={() => logAmz('productsAnalyzed')}
                          className="px-2.5 py-1.5 rounded-lg border border-emerald-500/25 text-emerald-400/70 bg-emerald-500/8 text-xs font-semibold hover:bg-emerald-500/15 transition-colors">
                          +1
                        </button>
                      </div>
                    </div>
                  )
                })()}
              </div>

              {/* Flow */}
              <div className="rounded-xl border border-white/10 bg-white/5 px-4 divide-y divide-white/5">
                <div className="py-3"><span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Flow</span></div>
                {([
                  { label: 'Products listed', done: todayAmz?.productsListed ?? 0, field: 'productsListed' as const },
                  { label: 'Orders received', done: todayAmz?.orders          ?? 0, field: 'orders'          as const },
                ] as const).map(row => {
                  const isPrior = todayPriority?.field === row.field
                  return (
                    <div key={row.label} className={`flex items-center gap-3 py-3.5 ${isPrior ? '-mx-4 px-4 bg-amber-500/6 border-l-2 border-amber-400/40' : ''}`}>
                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${row.done > 0 ? 'bg-emerald-500' : 'bg-white/15'}`} />
                      <div className="flex-1 flex items-center gap-2">
                        <span className={`text-sm font-semibold ${row.done > 0 ? 'text-emerald-400/70' : 'text-white/70'}`}>{row.label}</span>
                        {isPrior && <span className="text-[9px] px-1.5 py-0.5 rounded border border-amber-500/25 bg-amber-500/10 text-amber-400/70 font-semibold">Priority</span>}
                      </div>
                      <span className={`text-sm font-bold tabular-nums ${row.done > 0 ? 'text-emerald-400/70' : 'text-white/50'}`}>{row.done}</span>
                      <div className="flex items-center gap-1 shrink-0">
                        <button onClick={() => logAmz(row.field, -1)} disabled={row.done <= 0}
                          className="px-2.5 py-1.5 rounded-lg border border-white/12 text-white/35 bg-white/4 text-xs font-semibold hover:bg-white/8 disabled:opacity-30 transition-colors">
                          −1
                        </button>
                        <button onClick={() => logAmz(row.field)}
                          className="px-2.5 py-1.5 rounded-lg border border-emerald-500/25 text-emerald-400/70 bg-emerald-500/8 text-xs font-semibold hover:bg-emerald-500/15 transition-colors">
                          +1
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* Revenue */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-3">
                <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Revenue</span>
                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-lg border border-white/8 bg-white/3 px-3 py-2.5 flex flex-col gap-0.5">
                    <span className="text-[9px] text-white/50 uppercase tracking-widest">Today</span>
                    <span className="text-lg font-bold text-emerald-400">${(todayAmz?.revenue ?? 0).toLocaleString()}</span>
                  </div>
                  <div className="rounded-lg border border-white/8 bg-white/3 px-3 py-2.5 flex flex-col gap-0.5">
                    <span className="text-[9px] text-white/50 uppercase tracking-widest">Cumulative</span>
                    <span className="text-lg font-bold text-white/55">${stageTotals.amz.revenue.toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <input type="number" step={0.01} value={amzRevInput}
                    onChange={e => setAmzRevInput(e.target.value)} placeholder="Amount ($)"
                    className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/20 transition-colors" />
                  <button onClick={logAmzRevenue}
                    className="px-3 py-2 rounded-lg border border-emerald-500/25 bg-emerald-500/8 text-emerald-400/70 text-sm font-semibold hover:bg-emerald-500/15 transition-colors shrink-0">
                    +Add
                  </button>
                  <button
                    onClick={() => {
                      const n = parseFloat(amzRevInput)
                      if (isNaN(n) || n < 0) return
                      logAmz('revenue', n - (todayAmz?.revenue ?? 0))
                      setAmzRevInput('')
                    }}
                    className="px-3 py-2 rounded-lg border border-white/12 bg-white/4 text-white/40 text-sm font-semibold hover:bg-white/8 transition-colors shrink-0">
                    Set
                  </button>
                </div>
              </div>

              {/* Conversions */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-3">
                <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Conversion (this week)</span>
                <div className="flex flex-col gap-2">
                  {[
                    { label: 'Analyzed → Listed', pct: weeklyData.analyzedListed, a: weeklyData.amz.productsListed, b: weeklyData.amz.productsAnalyzed },
                    { label: 'Listed → Order',    pct: weeklyData.listedOrder,    a: weeklyData.amz.orders,          b: weeklyData.amz.productsListed   },
                  ].map(c => (
                    <div key={c.label} className="flex items-center justify-between px-3 py-2.5 rounded-lg border border-white/8 bg-white/3">
                      <div>
                        <span className="text-xs text-white/50">{c.label}</span>
                        <span className="text-[9px] text-white/45 ml-2">{c.a} / {c.b}</span>
                      </div>
                      <span className={`text-sm font-black tabular-nums ml-3 shrink-0 ${
                        c.pct === null ? 'text-white/45' : c.pct >= 20 ? 'text-emerald-400' : c.pct >= 10 ? 'text-amber-400' : 'text-red-400'
                      }`}>{c.pct !== null ? `${c.pct}%` : '—'}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Weekly totals */}
              <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-3">
                <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">This Week</span>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: 'Analyzed', value: weeklyData.amz.productsAnalyzed },
                    { label: 'Listed',   value: weeklyData.amz.productsListed   },
                    { label: 'Orders',   value: weeklyData.amz.orders            },
                    { label: 'Revenue',  value: weeklyData.amz.revenue, prefix: '$' },
                  ].map(item => (
                    <div key={item.label} className="rounded-lg border border-white/8 bg-white/3 px-3 py-2 flex flex-col gap-0.5">
                      <span className="text-[9px] text-white/50 uppercase tracking-widest">{item.label}</span>
                      <span className="text-sm font-bold text-white/60 tabular-nums">
                        {item.prefix}{item.value.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
            )
          })()}
        </div>
      )}

      {/* ── FEEDBACK ────────────────────────────────────────────────────── */}
      {activeTab === 'feedback' && (
        <div className="flex flex-col gap-4">

          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold tracking-widest text-white/40 uppercase">Weekly Summary</span>
            <span className="text-[10px] text-white/45 font-mono">{weekDays[0]?.iso} → {weekDays[6]?.iso}</span>
          </div>

          {/* Stage 1 Evidence — cumulative all-time progress toward Self-Control requirements */}
          {currentMotionStage.id === 1 && (
            <div className="rounded-xl border border-emerald-500/15 bg-white/5 p-4 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-white/55 uppercase tracking-widest font-semibold">Stage 1 Evidence</span>
                <span className="text-[9px] text-white/42">cumulative all-time</span>
              </div>
              <div className="flex flex-col gap-2">
                {[
                  { label: 'Emails sent',  value: stageTotals.svc.emails, target: STAGE_SVC_EMAILS },
                  { label: 'Calls done',   value: stageTotals.svc.calls,  target: STAGE_SVC_CALLS  },
                  { label: 'Deals closed', value: stageTotals.svc.deals,  target: STAGE_SVC_DEALS  },
                  { label: 'Revenue (this month)', value: currentMonthRev.total, target: STAGE_REVENUE, isCurrency: true },
                ].map(item => {
                  const pct = Math.min(100, Math.round((item.value / item.target) * 100))
                  const met = item.value >= item.target
                  const valStr = 'isCurrency' in item && item.isCurrency ? `$${item.value.toLocaleString()}` : item.value.toLocaleString()
                  const tgtStr = 'isCurrency' in item && item.isCurrency ? `$${item.target.toLocaleString()}` : item.target.toLocaleString()
                  return (
                    <div key={item.label} className="flex flex-col gap-1">
                      <div className="flex justify-between items-baseline">
                        <span className="text-[10px] text-white/40">{item.label}</span>
                        <span className={`text-[10px] font-mono font-bold tabular-nums ${met ? 'text-emerald-400/80' : 'text-white/40'}`}>
                          {valStr} / {tgtStr}{met ? ' ✓' : ''}
                        </span>
                      </div>
                      <div className="h-1 bg-white/8 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${met ? 'bg-emerald-500/55' : 'bg-emerald-500/30'}`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* Totals */}
          <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-3">
            <span className="text-[10px] text-white/55 uppercase tracking-widest font-semibold">Totals</span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'Emails',    value: String(weeklyData.svc.emails)               },
                { label: 'Calls',     value: String(weeklyData.svc.calls)                },
                { label: 'Mtg Bkd',  value: String(weeklyData.svc.meetingsBooked)        },
                { label: 'Mtg Held', value: String(weeklyData.svc.meetingsHeld)          },
                { label: 'Deals',    value: String(weeklyData.svc.deals)                 },
                { label: 'Svc Rev',  value: `$${weeklyData.svc.revenue.toLocaleString()}` },
                { label: 'Analyzed', value: String(weeklyData.amz.productsAnalyzed)      },
                { label: 'Listed',   value: String(weeklyData.amz.productsListed)        },
                { label: 'Orders',   value: String(weeklyData.amz.orders)                },
                { label: 'Amz Rev',  value: `$${weeklyData.amz.revenue.toLocaleString()}` },
                { label: 'Deep Wk',  value: fmtMin(weeklyData.dwMin)                    },
              ].map(item => (
                <div key={item.label} className="rounded-lg border border-white/8 bg-white/3 px-2.5 py-2 flex flex-col gap-0.5">
                  <span className="text-[9px] text-white/50 uppercase tracking-widest">{item.label}</span>
                  <span className="text-sm font-bold text-white/60 tabular-nums">{item.value || '0'}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Conversions */}
          <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-2">
            <span className="text-[10px] text-white/55 uppercase tracking-widest font-semibold mb-1">Conversion</span>
            {[
              { label: 'Email + Call → Meeting booked', pct: weeklyData.emailCallToMtg, a: weeklyData.svc.meetingsBooked, b: weeklyData.svc.emails + weeklyData.svc.calls },
              { label: 'Meeting booked → Meeting held', pct: weeklyData.mtgBookedHeld,  a: weeklyData.svc.meetingsHeld,   b: weeklyData.svc.meetingsBooked               },
              { label: 'Meeting held → Deal',           pct: weeklyData.mtgHeldDeal,    a: weeklyData.svc.deals,           b: weeklyData.svc.meetingsHeld                 },
              { label: 'Analyzed → Listed',             pct: weeklyData.analyzedListed, a: weeklyData.amz.productsListed, b: weeklyData.amz.productsAnalyzed             },
              { label: 'Listed → Order',                pct: weeklyData.listedOrder,    a: weeklyData.amz.orders,          b: weeklyData.amz.productsListed               },
            ].map(c => (
              <div key={c.label} className="flex items-center justify-between px-3 py-2 rounded-lg border border-white/8 bg-white/3">
                <div>
                  <span className="text-[10px] text-white/45">{c.label}</span>
                  <span className="text-[9px] text-white/42 ml-2">{c.a} / {c.b}</span>
                </div>
                <span className={`text-sm font-black tabular-nums ml-3 shrink-0 ${
                  c.pct === null ? 'text-white/45' : c.pct >= 20 ? 'text-emerald-400/80' : c.pct >= 10 ? 'text-amber-400/80' : 'text-red-400/80'
                }`}>{c.pct !== null ? `${c.pct}%` : '—'}</span>
              </div>
            ))}
          </div>

          {/* Daily target completion */}
          <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-3">
            <span className="text-[10px] text-white/55 uppercase tracking-widest font-semibold">Daily Target Completion</span>
            <div className="grid grid-cols-2 gap-2">
              <PctCard label="Emails (wkdays)"   pct={weeklyData.emailsPct}   />
              <PctCard label="Calls (wkdays)"    pct={weeklyData.callsPct}    />
              <PctCard label="Products (wknds)"  pct={weeklyData.productsPct} />
              <PctCard label="Deep Work (daily)" pct={weeklyData.dwPct}       />
            </div>
          </div>

          {/* Weakest area (raw — all metrics) */}
          {weeklyData.weakest && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg border border-amber-500/15 bg-amber-500/4">
              <span className="text-[9px] text-white/50 uppercase tracking-widest shrink-0">Weakest area</span>
              <span className="text-xs text-amber-400/70 font-semibold">{weeklyData.weakest.label}</span>
              <span className="ml-auto text-[10px] text-amber-400/45 font-mono">{weeklyData.weakest.pct}%</span>
            </div>
          )}

          {/* Stage-aware priority focus (required + focus only) */}
          {motionWeakestArea && motionWeakestArea.score < 100 && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg border border-red-500/15 bg-red-500/4">
              <span className="text-[9px] text-white/50 uppercase tracking-widest shrink-0">Priority focus</span>
              <span className="text-xs text-red-400/70 font-semibold">{motionWeakestArea.label}</span>
              <span className="text-[9px] text-white/42 ml-1 capitalize shrink-0">({motionWeakestArea.status})</span>
              <span className="ml-auto text-[10px] text-red-400/45 font-mono">{motionWeakestArea.score}%</span>
            </div>
          )}

          {/* Outreach / deal-flow warnings */}
          {motionWarnings.length > 0 && (
            <div className="flex flex-col gap-1 px-3 py-2.5 rounded-lg border border-amber-500/15 bg-amber-500/4">
              <span className="text-[9px] text-amber-400/60 uppercase tracking-widest font-semibold mb-0.5">Warnings</span>
              {motionWarnings.map((w, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-amber-400/40 text-[10px] shrink-0">·</span>
                  <span className="text-[10px] text-white/40">{w}</span>
                </div>
              ))}
            </div>
          )}

          {/* Missed days */}
          {weeklyData.missed.length > 0 ? (
            <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-2">
              <span className="text-[9px] text-white/50 uppercase tracking-widest mb-0.5">Missed days</span>
              {weeklyData.missed.map((item, i) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-red-400/45 text-[10px] mt-px shrink-0">·</span>
                  <span className="text-[10px] text-white/35">{item}</span>
                </div>
              ))}
            </div>
          ) : weeklyData.emailsPct !== null || weeklyData.productsPct !== null ? (
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg border border-emerald-500/15 bg-emerald-500/4">
              <span className="text-[10px] text-emerald-400/65">✓ No missed days this week</span>
            </div>
          ) : (
            <p className="text-[10px] text-white/45 italic">No completed days yet this week.</p>
          )}

          {/* Past 4 weeks history */}
          {weeklyHistory.some(w => w.hasData) && (
            <div className="rounded-xl border border-white/10 bg-white/5 p-4 flex flex-col gap-3">
              <span className="text-[10px] text-white/55 uppercase tracking-widest font-semibold">Past Weeks</span>
              <div className="flex flex-col gap-2">
                {weeklyHistory.filter(w => w.hasData).map(w => (
                  <div key={w.weekStart} className="flex flex-col gap-1.5 px-3 py-2.5 rounded-lg border border-white/8 bg-white/3">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-mono text-white/55">{w.weekStart} → {w.weekEnd}</span>
                      <span className={`text-[10px] font-bold font-mono tabular-nums ${w.totalRev > 0 ? 'text-emerald-400/70' : 'text-white/50'}`}>
                        ${w.totalRev.toLocaleString()}
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[
                        { label: 'Emails', value: w.svc.emails },
                        { label: 'Calls',  value: w.svc.calls  },
                        { label: 'Deals',  value: w.svc.deals  },
                        { label: 'Amz',    value: w.amz.analyzed },
                      ].map(item => (
                        <div key={item.label} className="flex flex-col gap-0.5">
                          <span className="text-[8px] text-white/45 uppercase tracking-widest">{item.label}</span>
                          <span className="text-xs font-bold text-white/45 tabular-nums">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <p className="text-[9px] text-white/40 italic">Service = weekdays · Amazon = weekends · Today excluded · Week = Sun–Sat</p>
        </div>
      )}

    </div>
  )
}
